/*
 * Robot.h
 *
 *  Created on: Jan 31, 2015
 *      Author: meghamallya
 */

#ifndef ROBOT_H_
#define ROBOT_H_

class Robot: public {
public:
	Robot();
	virtual ~Robot();
};

#endif /* ROBOT_H_ */
